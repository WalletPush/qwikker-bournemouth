import { redirect } from 'next/navigation'

export default function BusinessDashboardPage() {
  // Redirect to the main dashboard
  redirect('/dashboard')
}
