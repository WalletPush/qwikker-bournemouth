import { redirect } from 'next/navigation'

export default function BusinessPage() {
  // Redirect to the main dashboard
  redirect('/dashboard')
}
